
%% This Script contains Automation of Build and Run of Simulink Model
%Authors
%PS no.:(99003740),(99003747),(99003752),(99003761),(99003785)
%% Function to create .slx File
function autoCreateModel
fname = 'autoCreatedModel';
if exist(fname,'file') == 4
    if bdIsLoaded(fname)
        close_system(fname,0)
    end
    delete([fname,'.mdl']);
end
%% Read the .xlsx file to get data for building the simulink model
[num,txt,raw] = xlsread('test_cases_used.xlsx');
[row col]=size(txt);
%% Read the operation from .xlsx file
new_system(fname);
for i=2:row
    assignin('base',txt{i,3}, num(1));
    assignin('base',txt{i,5}, num(2));
    op = 'opeartion';
    
 %% Select the operation and add the respective blocks into the model
switch(txt{i,4})
    case '+'
        op = sprintf('Add%d',i);
        add_block('simulink/Math Operations/Add', [gcs,strcat('/',op)]);
    case '-'
        op =sprintf('Sub%d',i);
        add_block('simulink/Math Operations/Subtract', [gcs,strcat('/',op)]);
    case '/'
        op = sprintf('Div%d',i);
        add_block('simulink/Math Operations/Divide', [gcs,strcat('/',op)]);
    case '*'
        op = sprintf('Mul%d',i);
        add_block('simulink/Math Operations/Product', [gcs,strcat('/',op)]);
    case '&'
        op = sprintf('AND_Op%d',i);
        add_block('simulink/Quick Insert/Logic and Bit Operations/AND', [gcs,strcat('/',op)]);
    case '|'
        op = sprintf('OR%d',i);
        add_block('simulink/Quick Insert/Logic and Bit Operations/OR', [gcs,strcat('/',op)]);
    case '^'
        op = sprintf('XOR%d',i);
        add_block('simulink/Quick Insert/Logic and Bit Operations/XOR', [gcs,strcat('/',op)]);
end
%% Assign the values to the Constant blocks and Connect all the interconnected blocks 
add_block('built-in/Constant', [gcs,sprintf('/%s',txt{i,3})],'Value',txt{i,3});
add_block('built-in/Constant', [gcs,sprintf('/%s',txt{i,5})],'Value',txt{i,5});
add_line(gcs,sprintf('%s/1',txt{i,3}),strcat(op,'/1'))
add_line(gcs,sprintf('%s/1',txt{i,5}),strcat(op,'/2'))
add_block('simulink/Sinks/Display', [gcs,strcat('/',txt{i,1})]);
add_line(gcs,strcat(op,'/1'),strcat(txt{i,1},'/1'))
set_param(gcs,'Solver','FixedStepDiscrete','FixedStep','0.1');
%% Run the model 
simOut = sim(fname,'SaveOutput','on','OutputSaveName','yOut','SaveTime','on','TimeSaveName','tOut');
%% Save the model 
save_system(fname);
end


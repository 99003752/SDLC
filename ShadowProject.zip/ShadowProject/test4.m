clear;
clc;
fname = 'Model';
[num,txt] = xlsread('test_cases_used.xlsx');
[row col]=size(txt);
open_system(fname)
BlockPaths = find_system(fname,'Type','Block')
OutPortPaths=find_system(fname,'regexp','on','blocktype','Outport')
Length_OutPortPaths=length(OutPortPaths);
for i=1:Length_OutPortPaths
    P=OutPortPaths{i,1};
    s=length(P);
    InP=' ';
    for i=1:s
        n=s-i+1;
        if P(n)=='/'
            break
        else
            InP(i)=P(n);
        end
    end
    OutPort=reverse(InP)
end

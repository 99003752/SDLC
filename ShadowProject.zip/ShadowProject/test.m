load_system('test')
BlockParameterValue=get_param('test/Susbsyetem/In1','ObjectParameters')


BlockPaths = find_system('test','Type','Block')
%ModelParameterNames = get_param('test','ObjectParameters')
BlockDialogParameters = get_param('test/Subsystem1/Subsystem/In1','DialogParameters')
%BlockParameterValue = get_param('test','Step1')
%set_param('testing/Step1', 'Time', '10')
%  get_param('test/Subsystem1/Subsystem/In1', 'OutDataTypeStr')
%  set_param('test/Subsystem1/Subsystem/In1', 'OutDataTypeStr','half')
%  get_param('test/Subsystem1/Subsystem/In1', 'OutDataTypeStr')
get_param('test/Subsystem1/In2', 'OutDataTypeStr')
set_param('test/Subsystem1/In2', 'OutDataTypeStr','double')
get_param('test/Subsystem1/In2', 'OutDataTypeStr')
 %set_param('testing/Step1', 'Time', '10')
% %BlockTypes = get_param(BlockPaths,'BlockType')
% % get the port handles
% % get the output port data type
% testing([],[],[],'term')
% model = 'test';
% open_system(model)
% activeConfigObj = getActiveConfigSet(model);
% get_param(activeConfigObj,'StopTime')
% set_param(activeConfigObj,'StopTime','200');
% set_param(activeConfigObj,'SolverType','Variable-step');
% [raw0_1] = xlsread('test_cases_used.xlsx','in','A1:A4')
% [raw0_2] = xlsread('test_cases_used.xlsx','in','B1:B4')
% [raw0_3] = xlsread('test_cases_used.xlsx','in','C1:C4')
test([],[],[],'compile')
% run(model)
test([],[],[],'term')
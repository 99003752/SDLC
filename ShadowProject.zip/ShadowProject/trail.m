clear;
clc;
fname = 'Model';
[num,ExcelData] = xlsread('test_cases_used.xlsx');
open_system(fname)
BlockPaths = find_system(fname,'Type','Block')
InPortPaths=find_system(fname,'regexp','on','blocktype','port')
UpdateData='OutDataTypeStr'
Update(InPortPaths,ExcelData,UpdateData)


  
function Update(InPortPaths,ExcelData,UpdateData)
Length_InPortPaths=length(InPortPaths);
[row col]=size(ExcelData);
for i=1:Length_InPortPaths
    P=InPortPaths{i,1};
    s=length(P);
    InP=' ';
    for i=1:s
        n=s-i+1;
        if P(n)=='/'
            break
        else
            InP(i)=P(n);
        end
    end
    Port=reverse(InP);
    for i=2:row
        Po=ExcelData{i,1};
        Port_given=string(Po);
        New_Datatype=ExcelData{i,3};
        New_Datatype=string(New_Datatype);
        Pre_Datatype=ExcelData{i,2};
        Pre_Datatype=string(Pre_Datatype);
        Per=get_param(P, UpdateData);
        if Port_given==Port
            Cp=Port
            if Per==New_Datatype 
                new=get_param(P, UpdateData);
            else
                set_param(P, UpdateData,New_Datatype);
                new=get_param(P, UpdateData);
            end
        else 
            new=get_param(P, UpdateData); 
        end
    end
end
end
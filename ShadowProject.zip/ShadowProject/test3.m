clear;
clc;
fname = 'Model';
open_system(fname)
BlockPaths = find_system(fname,'Type','Block')
PortPaths=find_system(fname,'regexp','on','blocktype','port')
[num,txt] = xlsread('test_cases_used.xlsx')
[row col]=size(txt)
for i=2:row
    Port=txt{i,1}
    New_Datatype=txt{i,3};
    New_Datatype=string(New_Datatype)
    Pre_Datatype=txt{i,2};
    Pre_Datatype=string(Pre_Datatype);
    path=PortPaths{i-1,1}
    Per=get_param(path, 'OutDataTypeStr')
    if Per == New_Datatype 
        new=get_param(path, 'OutDataTypeStr')
    else
        set_param(path, 'OutDataTypeStr',New_Datatype)
        new=get_param(path, 'OutDataTypeStr')
    end
end
simOut = sim(fname,'SaveOutput','on','OutputSaveName','yOut','SaveTime','on','TimeSaveName','tOut');
